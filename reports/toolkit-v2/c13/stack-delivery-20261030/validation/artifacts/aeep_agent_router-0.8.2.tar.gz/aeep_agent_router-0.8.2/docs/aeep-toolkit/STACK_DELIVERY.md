# Run an assembled evaluation workflow

Use one reviewed workflow to choose a capability configuration, run its existing
assessment and inspect canonical results. The Toolkit connects benchmark inputs,
workers, protected grading, telemetry and reporting. It reuses AssessmentService
and BenchmarkRunner; it adds no scheduler, database or hosted service.

The [component audit](../../reports/toolkit-v2/c13/stack-delivery-20261030/README.md)
distinguishes actual upstream execution from report import, fixtures and research.
The managed fallback remains selected under D40. Agent-skill-eval 0.7.0 remains
the preferred upstream for its supported scripted path; its tested Codex contract
does not satisfy managed evaluation requirements.

## Select an existing assessment

Start with exported, reviewed AssessmentPlan and SourcePin JSON files. They must
describe the same canonical skill/plugin assessment stored in the existing
assessment directory. SourcePin binds the inspected subject's complete dependency
map. Preparing that plan, inspecting dependencies, reviewing authority and
qualifying its workers remain the existing assessment operations described in
[managed evaluation](MANAGED_EVALUATION.md).

From the repository root:

```bash
PYTHONPATH=src python3 -m aeep_toolkit workflow bind \
  --configuration repository-helper \
  --plan /absolute/reviewed-plan.json \
  --source /absolute/reviewed-source.json
```

This prints a workflow definition with exact file hashes. Save it privately as
`workflow.json`. Its `configurations` object can contain up to 16 named entries
produced this way, each with its own frozen plan and source. Names select plans;
they do not enable components, prove usefulness or grant execution authority.
Absolute paths are local bindings; relative paths resolve beside the workflow
file. Traversal, linked input paths and credential metadata are rejected.

Review the selected configuration without starting a worker or opening a database:

```bash
PYTHONPATH=src python3 -m aeep_toolkit workflow plan \
  --workflow /absolute/workflow.json \
  --configuration repository-helper
```

The preview shows the existing backend review, task families, candidate inventory
and exposure mode. Its review digest binds the workflow, selected files and
current adapter source. A changed configuration or file needs a new preview.
All three acceptance gates remain unassessed by this command.

## Execute and inspect

After obtaining applicable exact execution authority, run the selected plan:

```bash
PYTHONPATH=src python3 -m aeep_toolkit workflow run \
  --workflow /absolute/workflow.json \
  --configuration repository-helper \
  --reviewed-digest WORKFLOW_REVIEW_SHA256 \
  --manifest /absolute/aeep.yaml \
  --directory /absolute/existing-assessments \
  --output /absolute/new-private-report
```

This delegates to `eval managed run`. The existing service rechecks canonical
definitions, grant, accounting, worker identity, conformance and recovery. The
workflow file cannot install software, start supporting services or amend grants.
An interrupted or denied invocation is not retried by this command. Inspect its
canonical job and retained attempts before any further execution.

The new private output directory contains normalized evidence, original analysis
references, accounting records and `report.html`/`report.md`. Missing telemetry
and unnormalized trials remain visible. Auxiliary arms stay in canonical analysis
and accounting. They are not silently treated as normalized primary-arm evidence.

To export an existing completed report without dispatch, use the same arguments
with `workflow report` instead of `workflow run`, adding `--report-id REPORT_ID`.
Current-source and canonical binding checks still apply. Old terminal campaigns
retain their own source scope; do not rerun them to make a new export pass.

## Acceptance gates

These three gates are independent. Historical checkpoint passes retain their
original definitions and evidence tiers.

| Gate | What must be demonstrated | What cannot pass it |
| --- | --- | --- |
| Working stack integration | An operator selects a bound configuration and completes the actual CLI path through applicable workers, benchmark/grader, receipt-bound telemetry and canonical HTML/Markdown; failure/recovery preserves costs | A catalog, installed package, preview, mock result or independently tested components |
| Candidate usefulness | Qualified capability versus the capable shared baseline on independent representative tasks, with optional use in value trials and frozen utility/guardrails | Stack operation, forced invocation, instruction loading or more repetitions of exposed tasks |
| AEEP selection usefulness | Same candidate inventory and authority for discovery/fixed-policy and AEEP arms; actual pre-task selections, independent outcomes and complete decision overhead demonstrate AEEP's increment | An oracle choosing after outcomes, discovery's gain, refusal to admit one bad report or a selector scoring fixture |

Resource qualification and public release retain separate records. Whole-system
budgets require representative workload measurements. Proposed thresholds do not
become product requirements because a fixture meets them.

## Differentiated capabilities and configurations

The next demonstration targets repository maintenance with executable specialists:
Ruff's selected safe automatic fixes and LibCST's structural codemods. Their
mechanisms differ from a general instruction skill: one applies lint-rule fixes;
the other transforms Python syntax with metadata. These are candidate hypotheses,
not established improvements to an already capable agent. See the primary
[Ruff](https://docs.astral.sh/ruff/linter/) and
[LibCST](https://libcst.readthedocs.io/en/latest/codemods.html) interfaces.

Reuse public repository snapshots and their existing protected regression tests.
Include tasks requiring lint cleanup, API migration across files, both operations
and neither. Added intent checks must be independently validated against correct,
partial and destructive repairs before model assessment. Authored maintenance
tasks must be labeled separately from published upstream issues. Protect answers
and future cases, and retain existing exposure exclusions.

Evaluate ordinary tools, optional specialist A, optional specialist B and optional
A+B as distinct frozen configurations. Keep the ordinary baseline capable. Compare
the bundle with its useful individual components; adding two tools does not imply
that their combination helps. First validate the implementations and boundaries,
then measure optional-use value. The current skill bridge does not by itself
qualify arbitrary tool bundles or multi-tool exposure telemetry.

Only after candidate evidence exists should a frozen task-specific AEEP selector
be compared with discovery-only and a strong fixed policy chosen from prior data.
Use the existing three-way assessment and selection-report contracts. Give those
policies equal inventory, models, budgets and permissions. Grade inappropriate
selection, missed useful capability and abstention separately from task success.
Never supply held-out usefulness labels to the selector.

The existing Ponytail comparisons remain valid negative/inconclusive evidence for
their tested scopes. Preserve their reports, charged turns and source bindings.
They are not another run in this demonstration or a reason to fill test counts.

## Current verification boundary

The new workflow interface has offline contract tests, including canonical report
export from explicit synthetic records. An actual historical plan was bound and
previewed without execution. Neither supplies fresh worker conformance or a new
live end-to-end run. The component audit and its execution record identify the
remaining work; no gate is promoted by this guide.
