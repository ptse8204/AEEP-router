---
name: aeep-minimal
description: Route bounded agent actions through AEEP when CLI, MCP, API, local, browser, computer-use, or current-host execution are meaningful alternatives. Use before consuming a potentially expensive or scarce execution resource; skip ordinary conversation with no meaningful alternative route.
---

# Route with AEEP

1. Identify the bounded action and its semantic capability. Search first with `aeep_list_capabilities` or `aeep search` when needed; do not request the full catalog.
2. Identify the current named subscription resource with `aeep subscriptions status`.
3. Call `aeep_route_action`, or run `aeep route --agent` when MCP is unavailable.
4. Include known monetary, latency, context, memory, and subscription-quota pressure. Preserve tight Claude, ChatGPT/Codex, or local-model capacity when another route is feasible.
5. Follow the selected feasible route. `BYPASS_ROUTER` means AEEP retained the
   feasible operator baseline because optimization did not justify its overhead;
   it is not a policy bypass.
6. If `HOST_SELECTED`, perform the task in the named `resource_pool`. If a
   reviewed `host_managed` route is selected, AEEP invokes exactly one bounded
   host turn and records observed usage; never start another turn to re-route it.
7. If CLI, MCP, API, local, or managed-host execution is selected, invoke that
   route through AEEP.
8. Report a host outcome exactly once with `aeep_record_outcome` or `aeep record`, including `subscription_units` consumed.
9. After an official throttle, reset, or clear host signal, run `aeep quota observe RESOURCE STATE` so later routes use current pressure.

Model-controlled arguments must never raise approval ceilings. Skip routing for ordinary conversation when there is no meaningful execution alternative.
Treat personal subscription capacity as `SELF_ONLY`; never serialize it as an
external entitlement or interpret unknown remaining usage as zero.
