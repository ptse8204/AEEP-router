from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest
import yaml


def test_ci_checkout_long_paths_do_not_change_persistent_git_config(tmp_path):
    git = shutil.which("git")
    if git is None:
        pytest.skip("Git is required to check checkout configuration")
    root = Path(__file__).resolve().parents[1]
    workflow = yaml.safe_load((root / ".github/workflows/ci.yml").read_text(encoding="utf-8"))
    steps = workflow["jobs"]["test"]["steps"]
    checkout = next(step for step in steps if step.get("uses", "").startswith("actions/checkout@"))
    global_config = tmp_path / "global.gitconfig"
    original = "[user]\n    name = checkout-fixture\n"
    global_config.write_text(original, encoding="utf-8")
    env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_CONFIG")}
    env.update({"GIT_CONFIG_GLOBAL": str(global_config), "GIT_CONFIG_NOSYSTEM": "1"})
    baseline = subprocess.run([git, "config", "--get", "core.longpaths"], cwd=tmp_path,
                              env=env, capture_output=True, text=True, check=False)
    assert baseline.returncode == 1
    configured = subprocess.run([git, "config", "--get", "core.longpaths"], cwd=tmp_path,
        env={**env, **checkout["env"]}, capture_output=True, text=True, check=False)
    assert configured.returncode == 0, configured.stderr
    assert configured.stdout.strip() == "true"
    assert global_config.read_text(encoding="utf-8") == original
    restored = subprocess.run([git, "config", "--get", "core.longpaths"], cwd=tmp_path,
                             env=env, capture_output=True, text=True, check=False)
    assert restored.returncode == 1
