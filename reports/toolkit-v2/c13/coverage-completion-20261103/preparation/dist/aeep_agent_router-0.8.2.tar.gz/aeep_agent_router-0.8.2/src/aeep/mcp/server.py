"""Dependency-light MCP server exposing the AEEP router.

The server supports:
- stateless MCP 2026-07-28 discovery and per-request metadata, and
- the legacy 2025-11-25 initialize handshake,

over newline-delimited stdio or Streamable HTTP-style JSON POSTs.

Only JSON-RPC messages are written to stdout in stdio mode. Diagnostics belong
on stderr so agent harnesses can safely parse the protocol stream.
"""

from __future__ import annotations

import asyncio
import hmac
import json
import os
import sys
from collections.abc import AsyncIterator, Mapping
from contextlib import asynccontextmanager
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from fastapi import Request as _FastAPIRequest

from ..errors import AEEPError, ApprovalRequired, ConfigurationError, ProtocolError
from ..integrations import export_tools
from ..models import ActionRequest, ExternalOutcomeReport, QuoteRequest, ResourceVector, SideEffect
from ..router import Router
from ..version import __version__
from .client import LEGACY_VERSION, MODERN_VERSION, UNSUPPORTED_PROTOCOL_VERSION
from .headers import decode_header_value, validate_tool_parameter_headers

JSONRPC_VERSION = "2.0"
HEADER_MISMATCH = -32020
_SERVER_INFO_KEY = "io.modelcontextprotocol/serverInfo"
_INSTRUCTIONS = (
    "For task planning, inspect aeep_discovery_status and host capabilities, then use aeep_stack_recommend. "
    "Search configured catalogs and use host web search for gaps. Compare named tools and skills; no metadata establishes admission. "
    "A recommendation is not execution readiness. Keep public stages separate from private task values. "
    "Use aeep_route_action to inspect alternatives and aeep_execute_action to execute. "
    "Report a selected host-delegated route exactly once with aeep_record_outcome. "
    "Economic evidence tools are read-only inspection operations; they cannot approve or settle."
)

_PRIVATE_ECONOMIC_FIELDS = frozenset(
    {
        "access_token",
        "api_key",
        "action_input",
        "action_output",
        "authorization",
        "billing_record_reference",
        "client_secret",
        "cookie",
        "credential",
        "credentials",
        "external_reference",
        "input",
        "invoice_reference",
        "output",
        "password",
        "payload",
        "private_key",
        "raw_input",
        "raw_output",
        "refresh_token",
        "secret",
        "secret_key",
        "source_reference",
        "token",
        "uri",
        "url",
    }
)


def _json_default(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    raise TypeError(f"cannot JSON encode {type(value).__name__}")


def _server_meta() -> dict[str, Any]:
    return {_SERVER_INFO_KEY: {"name": "aeep-agent-router", "version": __version__}}


def _tool_result(
    payload: Any,
    *,
    is_error: bool = False,
    usage: ResourceVector | None = None,
) -> dict[str, Any]:
    encoded = json.dumps(payload, ensure_ascii=False, default=_json_default)
    result: dict[str, Any] = {
        "content": [{"type": "text", "text": encoded}],
        "isError": is_error,
    }
    if isinstance(payload, dict):
        result["structuredContent"] = payload
    if usage is not None:
        result["_meta"] = {"org.aeep/usage": usage.model_dump(mode="json")}
    return result


def _economic_record_view(record: Any) -> dict[str, Any]:
    """Return an economic record without payloads, secrets, or external references."""

    def scrub(value: Any) -> Any:
        if isinstance(value, dict):
            return {
                key: scrub(item)
                for key, item in value.items()
                if key.lower() not in _PRIVATE_ECONOMIC_FIELDS
            }
        if isinstance(value, list):
            return [scrub(item) for item in value]
        return value

    payload = record.model_dump(mode="json")
    sanitized = scrub(payload)
    if not isinstance(sanitized, dict):  # pragma: no cover - Pydantic model invariant
        raise TypeError("economic record must serialize as an object")
    return sanitized


def _action_from_arguments(arguments: dict[str, Any]) -> ActionRequest:
    value: dict[str, Any] = {
        "capability": arguments["capability"],
        "input": arguments.get("input", {}),
        "policy": arguments.get("policy", "balanced"),
    }
    if "constraints" in arguments:
        value["constraints"] = arguments["constraints"]
    if "context" in arguments:
        value["context"] = arguments["context"]
    if "idempotency_key" in arguments:
        value["idempotency_key"] = arguments["idempotency_key"]
    return ActionRequest.model_validate(value)


def _sum_receipt_usage(receipts: list[Any]) -> ResourceVector:
    total = ResourceVector()
    for receipt in receipts:
        resources = getattr(receipt, "actual_resources", None)
        if isinstance(resources, ResourceVector):
            total = total.plus(resources)
    return total


def _request_version(params: Mapping[str, Any]) -> str | None:
    meta = params.get("_meta")
    if not isinstance(meta, Mapping):
        return None
    value = meta.get("io.modelcontextprotocol/protocolVersion")
    return str(value) if isinstance(value, str) else None


def _valid_modern_meta(params: Mapping[str, Any]) -> bool:
    meta = params.get("_meta")
    return (
        isinstance(meta, Mapping)
        and meta.get("io.modelcontextprotocol/protocolVersion") == MODERN_VERSION
        and isinstance(meta.get("io.modelcontextprotocol/clientInfo"), Mapping)
        and isinstance(meta.get("io.modelcontextprotocol/clientCapabilities"), Mapping)
    )


def _tool_by_name(tools: list[dict[str, Any]], name: str) -> dict[str, Any] | None:
    return next((tool for tool in tools if tool.get("name") == name), None)


class AEEPToolService:
    """Provider-neutral implementations behind MCP and generated tool schemas."""

    def __init__(
        self,
        router: Router,
        *,
        approved_side_effect: SideEffect = SideEffect.READ,
        allow_unsafe_executor: bool = False,
        profile: str = "legacy",
        task_scope: str | None = None,
        task_activation: str | None = None,
        discovery_config: Path | None = None,
        connection: Path | None = None,
    ) -> None:
        self.router = router
        from ..connections import bind_connection
        self.connection = bind_connection(router, connection) if connection else router._connection_guard
        # These are operator-controlled ceilings. Tool-call arguments are
        # untrusted model output and therefore cannot elevate approvals.
        self.approved_side_effect = approved_side_effect
        self.allow_unsafe_executor = allow_unsafe_executor
        if profile not in {"legacy", "assessment", "task"}:
            raise ConfigurationError("unknown tool profile")
        self.profile = profile
        self.stack_execution = False
        self.discovery = None
        self.discovery_path = discovery_config
        if discovery_config is not None:
            from ..discovery_service import DiscoveryConfig, DiscoveryService
            if profile == 'task':
                raise ConfigurationError('task profile cannot perform external discovery')
            with discovery_config.open('rb') as stream:
                configuration_bytes = stream.read(65_537)
            if len(configuration_bytes) > 65_536:
                raise ConfigurationError('discovery configuration exceeds 64 KiB')
            self.discovery = DiscoveryService.from_config(
                router.store, DiscoveryConfig.model_validate_json(configuration_bytes),
                base_directory=discovery_config.resolve().parent,
            )
        if task_activation is not None:
            from ..assessment.models import content_digest
            from ..tasks import require_activation
            if task_scope is not None or profile != 'task':
                raise ConfigurationError('task activation requires the task profile and cannot be combined with another scope')
            activation = require_activation(router, task_activation)
            router._task_activation_digest = content_digest(activation)
            if activation.capability_profile_digest:
                from ..profiles import load
                self.stack_execution = load(router, activation.capability_profile_digest).stack_execution
            task_scope = activation.scope_digest
        if task_scope is not None:
            if profile != 'task':
                raise ConfigurationError('task scope requires the task-only tool profile')
            scope_ceiling = router.bind_task_scope(task_scope)
            self.approved_side_effect = min(approved_side_effect, scope_ceiling, key=lambda level: level.rank)
        self.assessment_workers: list[Any] = []

    @property
    def instructions(self) -> str:
        if self.profile == 'task':
            return ('Use the available task tools within the operator scope. Results include recorded '
                    'verification limits and recovery state. No assessment or approval controls are exposed.')
        return _INSTRUCTIONS

    def _list_tools(self) -> list[dict[str, Any]]:
        if self.profile in {"assessment", "task"}:
            from ..assessment.tools import declarations
            if self.profile == 'task':
                specs = self.router.registry.all()
                if self.router._task_scope_digest is not None:
                    from ..assessment.repository import AssessmentRepository
                    from ..economic.prepared import executor_fingerprint
                    from ..models import TaskScope
                    scope = TaskScope.model_validate(AssessmentRepository(self.router.store).get('task_scope', self.router._task_scope_digest))
                    specs = [spec for spec in specs if scope.executor_fingerprints.get(spec.id) == executor_fingerprint(spec)]
                return declarations(self.router.store, tasks_only=True, capabilities={spec.capability for spec in specs},
                                    include_stack=self.stack_execution)
            return [item for item in declarations(self.router.store)
                    if item['name'] != 'aeep_discover_resources' or self.discovery is not None]
        return [item for item in export_tools("mcp")
                if item['name'] != 'aeep_discover_resources' or self.discovery is not None]

    def list_tools(self) -> list[dict[str, Any]]:
        tools = self._list_tools()
        if self.connection is not None:
            allowed = self.connection.current().allowed_tools
            tools = [tool for tool in tools if tool['name'] in allowed]
        return tools

    async def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        try:
            if self.connection is not None:
                self.connection.require_tool(name)
                if _tool_by_name(self.list_tools(), name) is None:
                    raise ConfigurationError('tool is not exposed by this service')
            if name == 'aeep_discovery_status':
                from ..catalogs import read_catalogs, source_status
                if arguments:
                    raise ConfigurationError('discovery status takes no arguments')
                return _tool_result(source_status(read_catalogs(self.discovery_path)) if self.discovery_path else {'sources': [], 'next_step': 'Run aeep setup and connect discovery configuration.'})
            if name == 'aeep_stack_recommend':
                from ..catalogs import read_catalogs
                from ..discovery_service import DiscoveryConfig
                from ..recommendations import RecommendationRequest, recommend
                if _tool_by_name(self.list_tools(), name) is None:
                    raise ConfigurationError('recommendation tool is not enabled')
                return _tool_result((await recommend(self.router, RecommendationRequest.model_validate(arguments),
                    config=read_catalogs(self.discovery_path) if self.discovery_path else DiscoveryConfig())).model_dump(mode='json'))
            if name.startswith('aeep_stack_'):
                from ..registry import validate_json
                from ..stack_models import GoalSpec, StackPreflight, StackProposal
                from ..stack_planning import StackService
                declaration = _tool_by_name(self.list_tools(), name)
                if declaration is None:
                    raise ConfigurationError('stack preparation tool is not enabled')
                validate_json(arguments, declaration['inputSchema'], label=name)
                service = StackService(self.router)
                if name == 'aeep_stack_run':
                    from ..stack_runtime import StackRuntime
                    if self.profile != 'task' or self.router._task_activation_digest is None:
                        raise ConfigurationError('stack execution requires an active task binding')
                    return _tool_result(await StackRuntime(service).run(arguments['proposal_id'], arguments['inputs'],
                        approved_side_effect=self.approved_side_effect))
                stack_result: StackProposal | StackPreflight
                if name == 'aeep_stack_propose':
                    stack_result = service.propose(GoalSpec.model_validate(arguments))
                elif name == 'aeep_stack_inspect':
                    stack_result = service.inspect(arguments['proposal_id'])
                elif name == 'aeep_stack_optimize':
                    stack_result = service.optimize(arguments['proposal_id'], arguments['policy'])
                else:
                    stack_result = service.preflight(arguments['proposal_id'])
                return _tool_result(stack_result.model_dump(mode='json'))
            if name in {'aeep_discover_resources', 'aeep_lookup_capability'}:
                from ..registry import validate_json
                declaration = _tool_by_name(self.list_tools(), name)
                if declaration is None:
                    raise ConfigurationError('capability preparation tool is not enabled')
                validate_json(arguments, declaration['inputSchema'], label=name)
                if name == 'aeep_discover_resources':
                    from ..discovery import DiscoveryRequest
                    if self.discovery is None:
                        raise ConfigurationError('discovery requires operator-configured sources')
                    result = await self.discovery.search(DiscoveryRequest.model_validate(arguments))
                    return _tool_result(result.model_dump(mode='json'))
                from ..capability_lifecycle import AdmissionLookupRequest, CapabilityLifecycle
                lookup = AdmissionLookupRequest.model_validate(arguments)
                admission_decision = CapabilityLifecycle.from_router(self.router).lookup(
                    lookup.candidate_id, lookup.request, intake_id=lookup.intake_id,
                )
                return _tool_result(admission_decision.model_dump(mode='json'))
            if self.profile in {"assessment", "task"}:
                from ..assessment.tools import call
                return await call(self, name, arguments)
            if name == "aeep_list_capabilities":
                payload = self.router.search_capabilities(
                    str(arguments.get("query", "")),
                    prefix=arguments.get("prefix"),
                    limit=int(arguments.get("limit", 20)),
                    cursor=int(arguments.get("cursor", 0)),
                    include_executors=bool(arguments.get("include_executors", False)),
                )
                return _tool_result(payload)
            if name == "aeep_route_action":
                decision = await self.router.route_with_discovery(_action_from_arguments(arguments))
                route_payload = (
                    decision
                    if arguments.get("detail") == "full"
                    else self.router.compact_decision(decision)
                )
                return _tool_result(route_payload.model_dump(mode="json"))
            if name == "aeep_execute_action":
                request = _action_from_arguments(arguments)
                outcome = await self.router.execute(
                    request,
                    approved_side_effect=self.approved_side_effect,
                    allow_unsafe_executor=self.allow_unsafe_executor,
                    dry_run=bool(arguments.get("dry_run", False)),
                )
                execution_payload = (
                    outcome
                    if arguments.get("detail") == "full"
                    else self.router.compact_outcome(outcome)
                )
                return _tool_result(
                    execution_payload.model_dump(mode="json"),
                    is_error=not outcome.ok,
                    usage=_sum_receipt_usage(outcome.receipts),
                )
            if name == "aeep_record_outcome":
                report = ExternalOutcomeReport.model_validate(arguments)
                receipt = self.router.record_external_outcome(report)
                return _tool_result(
                    receipt.model_dump(mode="json"),
                    usage=receipt.actual_resources,
                )
            if name in {"aeep_estimate_route_prices", "aeep_request_quotes"}:
                quote_request = QuoteRequest(
                    action=_action_from_arguments(arguments),
                    executor_ids=arguments.get("executor_ids"),
                )
                quotes = self.router.quotes(quote_request)
                return _tool_result({"quotes": [quote.model_dump(mode="json") for quote in quotes]})
            if name == "aeep_get_metrics":
                metrics = self.router.metrics(limit=int(arguments.get("limit", 10_000)))
                return _tool_result(metrics.model_dump(mode="json"))
            if name == "aeep_show_prepared_decision":
                prepared_id = str(arguments["prepared_id"])
                prepared = self.router.store.get_prepared_decision(prepared_id)
                if prepared is None:
                    return _tool_result(
                        {"error": f"prepared decision {prepared_id!r} was not found"},
                        is_error=True,
                    )
                return _tool_result(_economic_record_view(prepared))
            if name == "aeep_show_quote":
                quote_id = str(arguments["quote_id"])
                quote = self.router.store.get_bounded_quote(quote_id)
                if quote is None:
                    return _tool_result(
                        {"error": f"bounded quote {quote_id!r} was not found"},
                        is_error=True,
                    )
                return _tool_result(_economic_record_view(quote))
            if name == "aeep_show_settlement":
                settlement_id = str(arguments["settlement_id"])
                settlement = self.router.store.get_settlement_receipt(settlement_id)
                if settlement is None:
                    return _tool_result(
                        {"error": f"settlement {settlement_id!r} was not found"},
                        is_error=True,
                    )
                return _tool_result(_economic_record_view(settlement))
            return _tool_result({"error": f"unknown tool {name!r}"}, is_error=True)
        except ApprovalRequired as exc:
            return _tool_result(
                {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                    "executor_id": exc.executor_id,
                    "required_level": exc.required_level,
                },
                is_error=True,
            )
        except (AEEPError, ValueError, KeyError) as exc:
            return _tool_result(
                {"error": str(exc), "error_type": type(exc).__name__},
                is_error=True,
            )


class MCPProtocolApp:
    def __init__(self, service: AEEPToolService) -> None:
        self.service = service

    @staticmethod
    def _result(
        request_id: Any,
        result: dict[str, Any],
        *,
        modern: bool = False,
    ) -> dict[str, Any]:
        payload = dict(result)
        if modern:
            payload.setdefault("resultType", "complete")
            meta = payload.get("_meta")
            merged_meta = dict(meta) if isinstance(meta, dict) else {}
            merged_meta.setdefault(_SERVER_INFO_KEY, _server_meta()[_SERVER_INFO_KEY])
            payload["_meta"] = merged_meta
        return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "result": payload}

    @staticmethod
    def _error(request_id: Any, code: int, message: str, data: Any = None) -> dict[str, Any]:
        error: dict[str, Any] = {"code": code, "message": message}
        if data is not None:
            error["data"] = data
        return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "error": error}

    async def handle(self, message: dict[str, Any]) -> dict[str, Any] | None:
        request_id = message.get("id")
        if message.get("jsonrpc") != JSONRPC_VERSION:
            return self._error(request_id, -32600, "Invalid Request")
        method = message.get("method")
        params = message.get("params", {})
        if not isinstance(method, str) or not isinstance(params, dict):
            return self._error(request_id, -32600, "Invalid Request")

        # Notifications intentionally produce no JSON-RPC response.
        if request_id is None:
            return None

        version = _request_version(params)
        modern = method == "server/discover" or version == MODERN_VERSION
        if modern and not _valid_modern_meta(params):
            return self._error(request_id, -32600, "Modern request metadata is incomplete")

        if method == "server/discover":
            return self._result(
                request_id,
                {
                    "supportedVersions": [MODERN_VERSION, LEGACY_VERSION],
                    "capabilities": {"tools": {"listChanged": False}},
                    "instructions": self.service.instructions,
                    "ttlMs": 300_000,
                    "cacheScope": "private",
                },
                modern=True,
            )
        if method == "initialize":
            # initialize is a legacy-era handshake. A modern client uses
            # server/discover and per-request metadata instead.
            return self._result(
                request_id,
                {
                    "protocolVersion": LEGACY_VERSION,
                    "serverInfo": {"name": "aeep-agent-router", "version": __version__},
                    "capabilities": {"tools": {"listChanged": False}},
                    "instructions": self.service.instructions,
                },
            )
        if method == "ping":
            if modern:
                return self._error(request_id, -32601, "Method not found: ping")
            return self._result(request_id, {})
        if method == "tools/list":
            result: dict[str, Any] = {"tools": self.service.list_tools()}
            if modern:
                result.update({"ttlMs": 60_000, "cacheScope": "private"})
            return self._result(request_id, result, modern=modern)
        if method == "tools/call":
            name = params.get("name")
            arguments = params.get("arguments", {})
            if not isinstance(name, str) or not isinstance(arguments, dict):
                return self._error(request_id, -32602, "Invalid tools/call parameters")
            if _tool_by_name(self.service.list_tools(), name) is None:
                return self._error(request_id, -32602, f"Unknown tool: {name}")
            result = await self.service.call(name, arguments)
            return self._result(request_id, result, modern=modern)
        return self._error(request_id, -32601, f"Method not found: {method}")


def _http_error(request_id: Any, code: int, message: str, data: Any = None) -> dict[str, Any]:
    return MCPProtocolApp._error(request_id, code, message, data)


def _validate_modern_http_headers(
    message: dict[str, Any],
    headers: Mapping[str, str],
    tools: list[dict[str, Any]],
) -> None:
    method = message.get("method")
    params = message.get("params", {})
    if not isinstance(method, str) or not isinstance(params, dict):
        raise ProtocolError("invalid JSON-RPC request body")
    body_version = _request_version(params)
    header_version = headers.get("mcp-protocol-version")
    if header_version != body_version:
        raise ProtocolError("MCP-Protocol-Version does not match request _meta")
    if header_version != MODERN_VERSION:
        raise ProtocolError("modern MCP request must use the modern protocol version")
    if headers.get("mcp-method") != method:
        raise ProtocolError("Mcp-Method does not match request method")

    if method == "tools/call":
        name = params.get("name")
        arguments = params.get("arguments", {})
        if not isinstance(name, str) or not isinstance(arguments, dict):
            raise ProtocolError("invalid tools/call parameters")
        encoded_name = headers.get("mcp-name")
        if encoded_name is None or decode_header_value(encoded_name) != name:
            raise ProtocolError("Mcp-Name does not match request body")
        tool = _tool_by_name(tools, name)
        if tool is not None:
            validate_tool_parameter_headers(tool, arguments, headers)


async def serve_stdio(
    manifest: str | None = None,
    *,
    approved_side_effect: SideEffect = SideEffect.READ,
    allow_unsafe_executor: bool = False,
    max_message_bytes: int = 2_000_000,
    profile: str = "legacy",
    task_scope: str | None = None,
    task_activation: str | None = None,
    discovery_config: Path | None = None,
    connection: Path | None = None,
) -> None:
    """Run until stdin closes."""

    router = Router.from_manifest(manifest)
    app = MCPProtocolApp(
        AEEPToolService(
            router,
            approved_side_effect=approved_side_effect,
            allow_unsafe_executor=allow_unsafe_executor,
            profile=profile,
            task_scope=task_scope,
            task_activation=task_activation,
            discovery_config=discovery_config,
            connection=connection,
        )
    )
    max_bytes = max(1024, int(max_message_bytes))
    saved_stdout = os.dup(sys.stdout.fileno())
    protocol_stream = os.fdopen(os.dup(saved_stdout), "w", buffering=1, encoding="utf-8")
    os.dup2(sys.stderr.fileno(), sys.stdout.fileno())
    try:
        while True:
            line = await asyncio.to_thread(sys.stdin.buffer.readline, max_bytes + 1)
            if not line:
                break
            try:
                if len(line) > max_bytes:
                    while line and not line.endswith(b"\n"):
                        line = await asyncio.to_thread(sys.stdin.buffer.readline, max_bytes + 1)
                    raise ValueError("message exceeds configured size limit")
                message = json.loads(line)
                if not isinstance(message, dict):
                    raise ValueError("message must be a JSON object")
                response = await app.handle(message)
            except Exception as exc:  # protocol boundary: return a parse/internal error
                response = MCPProtocolApp._error(None, -32700, "Parse error", str(exc))
            if response is not None:
                payload = json.dumps(
                    response,
                    ensure_ascii=False,
                    separators=(",", ":"),
                    default=_json_default,
                )
                protocol_stream.write(payload + "\n")
    finally:
        os.dup2(saved_stdout, sys.stdout.fileno())
        os.close(saved_stdout)
        protocol_stream.close()
        await router.close()


def create_http_app(
    manifest: str | None = None,
    *,
    bearer_token: str | None = None,
    approved_side_effect: SideEffect = SideEffect.READ,
    allow_unsafe_executor: bool = False,
    max_body_bytes: int = 2_000_000,
    allowed_origins: set[str] | None = None,
    profile: str = "legacy",
    task_scope: str | None = None,
    task_activation: str | None = None,
    discovery_config: Path | None = None,
    connection: Path | None = None,
) -> Any:
    """Create an optional FastAPI app without making FastAPI a base dependency."""

    try:
        from fastapi import FastAPI, Header, HTTPException, Request, Response
        from fastapi.responses import JSONResponse
    except ImportError as exc:  # pragma: no cover - optional extra
        raise RuntimeError(
            "HTTP serving requires `pip install 'aeep-agent-router[http-server]'`"
        ) from exc

    # FastAPI resolves postponed annotations from module globals. Request is an
    # optional dependency imported locally, so expose only this runtime alias.
    globals()["_FastAPIRequest"] = Request

    router = Router.from_manifest(manifest)
    service = AEEPToolService(
        router,
        approved_side_effect=approved_side_effect,
        allow_unsafe_executor=allow_unsafe_executor,
        profile=profile,
        task_scope=task_scope,
        task_activation=task_activation,
        discovery_config=discovery_config,
        connection=connection,
    )
    protocol = MCPProtocolApp(service)

    @asynccontextmanager
    async def lifespan(_app: Any) -> AsyncIterator[None]:
        try:
            yield
        finally:
            await router.close()

    app = FastAPI(title="AEEP MCP Server", version=__version__, lifespan=lifespan)

    @app.get("/healthz")
    async def healthz() -> dict[str, Any]:
        return {"ok": True, "version": __version__}

    @app.post("/mcp")
    async def mcp_endpoint(
        request: _FastAPIRequest,
        authorization: str | None = Header(default=None),
    ) -> Any:
        if bearer_token:
            expected = f"Bearer {bearer_token}"
            if authorization is None or not hmac.compare_digest(authorization, expected):
                raise HTTPException(status_code=401, detail="invalid bearer token")
        origin = request.headers.get("origin")
        if origin is not None and origin not in (allowed_origins or set()):
            raise HTTPException(status_code=403, detail="origin is not allowed")
        if "application/json" not in request.headers.get("content-type", ""):
            raise HTTPException(status_code=415, detail="application/json is required")
        body = bytearray()
        async for chunk in request.stream():
            if len(body) + len(chunk) > max(1024, max_body_bytes):
                raise HTTPException(status_code=413, detail="request body too large")
            body.extend(chunk)
        try:
            message = json.loads(bytes(body))
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="invalid JSON") from exc
        if not isinstance(message, dict):
            raise HTTPException(status_code=400, detail="JSON-RPC message must be an object")

        method = message.get("method")
        params = message.get("params", {})
        body_version = _request_version(params) if isinstance(params, dict) else None
        header_version = request.headers.get("mcp-protocol-version")
        modern_request = (
            method == "server/discover"
            or body_version == MODERN_VERSION
            or header_version == MODERN_VERSION
        )

        if header_version is not None and header_version not in {MODERN_VERSION, LEGACY_VERSION}:
            return JSONResponse(
                status_code=400,
                content=_http_error(
                    message.get("id"),
                    UNSUPPORTED_PROTOCOL_VERSION,
                    f"Unsupported protocol version: {header_version}",
                    {"supported": [MODERN_VERSION, LEGACY_VERSION]},
                ),
            )

        if modern_request:
            try:
                _validate_modern_http_headers(message, request.headers, service.list_tools())
            except ProtocolError as exc:
                return JSONResponse(
                    status_code=400,
                    content=_http_error(message.get("id"), HEADER_MISMATCH, str(exc)),
                )

        result = await protocol.handle(message)
        if result is None:
            # 202 is the MCP-recommended response for accepted notifications.
            return Response(status_code=202)
        status_code = 200
        if modern_request and result.get("error", {}).get("code") == -32601:
            status_code = 404
        return JSONResponse(result, status_code=status_code)

    return app
